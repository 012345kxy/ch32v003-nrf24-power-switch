#ifndef APPLICATIONS_MOS_CTRL_H_
#define APPLICATIONS_MOS_CTRL_H_

#include "debug.h"

void Gate_IO_Init();
void Mos_ON();
void Mos_OFF();

#endif