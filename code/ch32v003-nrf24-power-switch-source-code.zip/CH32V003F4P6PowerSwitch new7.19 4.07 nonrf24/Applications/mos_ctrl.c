#include "mos_ctrl.h"
void Gate_IO_Init()
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_30MHz;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    GPIO_WriteBit(GPIOD,GPIO_Pin_4,0);
}

void Mos_ON()
{
    GPIO_WriteBit(GPIOD,GPIO_Pin_4,0);
    printf("MOS_ON\r\n");
}

void Mos_OFF()
{
    GPIO_WriteBit(GPIOD,GPIO_Pin_4,1);
    printf("MOS_OFF\r\n");
}