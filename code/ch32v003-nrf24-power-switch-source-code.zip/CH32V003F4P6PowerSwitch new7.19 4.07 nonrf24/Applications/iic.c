/*
 * iic.c
 *
 *  Created on: May 13, 2025
 *      Author: 17485
 */

# include "iic.h"
void I2C_W_SCL(uint8_t BITVALUE)
{
    GPIO_WriteBit(GPIOD, GPIO_Pin_6, (BitAction)BITVALUE);
    Delay_Us(5);

}

void I2C_W_SDA(uint8_t BITVALUE)
{
    GPIO_WriteBit(GPIOD, GPIO_Pin_7, (BitAction)BITVALUE);
    Delay_Us(5);

}

uint8_t I2C_R_SDA(void)
{
    uint8_t BITVALUE;
    BITVALUE=GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_7);
    Delay_Us(5);
    return BITVALUE;

}

void I2C_Init_(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);//GPIOB

    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    GPIO_SetBits(GPIOD, GPIO_Pin_2|GPIO_Pin_3);
}

void I2C_SendByte(uint8_t Byte)
{
    uint8_t i=0;
    for(i=0;i<8;i++)
    {
    I2C_W_SDA(Byte & (0x80>>i));//ȡ��byte��ÿһλ
    I2C_W_SCL(1);
    I2C_W_SCL(0);
    }

}

uint8_t I2C_ReceiveByte(void)
{
    uint8_t i,Byte = 0x00;
    I2C_W_SDA(1);
    for(i=0;i<8;i++)
    {
        I2C_W_SCL(1);
        if (I2C_R_SDA()==1){Byte|=(0x80>>i);}
        I2C_W_SCL(0);
    }
    return Byte;
}

void I2C_SendAck(uint8_t AckBit)
{
    I2C_W_SDA(AckBit);
    I2C_W_SCL(1);
    I2C_W_SCL(0);


}

uint8_t I2C_ReceiveAck(void)
{
    uint8_t AckBit;
    I2C_W_SDA(1);
    I2C_W_SCL(1);
    AckBit=I2C_R_SDA();
    I2C_W_SCL(0);
    return AckBit;
}
