/*
 * USER_ADC.h
 *
 *  Created on: 2025��7��13��
 *      Author: 012345kxy
 */

#ifndef APPLICATIONS_USER_ADC_H_
#define APPLICATIONS_USER_ADC_H_

void user_adc_init();
void user_adc_dma_init();

extern volatile u16 adc_value[3];


#endif /* APPLICATIONS_USER_ADC_H_ */
