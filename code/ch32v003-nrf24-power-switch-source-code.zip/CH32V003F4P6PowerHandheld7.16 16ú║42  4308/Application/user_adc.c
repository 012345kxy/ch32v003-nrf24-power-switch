/*
 * user_adc.c
 *
 *  Created on: 2025��7��13��
 *      Author: 012345kxy
 */
#include "debug.h"

void user_adc_init()
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div8);//��ADC��ʱ����6M

    GPIO_InitTypeDef GPIO_InitStructure = {0};
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

////////////////////////////////////////////////////////////////////////////////////////

    ADC_InitTypeDef  ADC_InitStructure = {0};
    ADC_DeInit(ADC1);
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;  //����ADC����ģʽ
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;  //�ⲿ��������
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;  //ɨ��ģʽ�����Զ��л�ADC_Channel_1��ADC_Channel_0
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;  //����ת����һֱ��ת��
    ADC_InitStructure.ADC_NbrOfChannel = 2;
    ADC_Init(ADC1, &ADC_InitStructure);


    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_241Cycles);  //ADC_CURRENT
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 2, ADC_SampleTime_241Cycles);  //ADC_VM

    ADC_DMACmd(ADC1,ENABLE);
    ADC_Cmd(ADC1, ENABLE);  //����ADC��Դ

    ADC_Calibration_Vol(ADC1, ADC_CALVOL_75PERCENT);
    ADC_ResetCalibration(ADC1);  //ADC��λУ׼
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));  //�ȴ�ADCУ׼����
}

volatile u16 adc_value[3]={0};

void user_adc_dma_init()
{
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_InitTypeDef DMA_InitStructure = {0};
    DMA_DeInit(DMA1_Channel1);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)&ADC1->RDATAR;  //�����ַ
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;   
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;  //�Ƿ�����������������Ȼת�˶��ͨ��������

    DMA_InitStructure.DMA_MemoryBaseAddr =(u32)adc_value;  //Ŀ�ĵص�ַ
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;   
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;  //�Ƿ���������

    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;  //���䷽������ΪSource

    DMA_InitStructure.DMA_BufferSize = 2;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;  //��ʹ����������
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);

    DMA_Cmd(DMA1_Channel1,ENABLE);

    ADC_SoftwareStartConvCmd(ADC1,ENABLE);
}
